#include "Command.h"

Command::Command(TaskManager& taskManager) : taskManager(taskManager)
{
}
